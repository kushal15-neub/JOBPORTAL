

<?php $__env->startSection('main'); ?>
<section class="section-5 bg-2">
    <div class="container py-5">
        <div class="row">
            <div class="col">
                <nav aria-label="breadcrumb" class="rounded-3 p-3">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="/my-jobs"><i class="fa fa-arrow-left" aria-hidden="true"></i> &nbsp;Back to My Jobs</a></li>
                    </ol>
                </nav>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col">
                <div class="card border-0 shadow">
                    <div class="card-header bg-white">
                        <h3 class="mb-0">Applications for: <?php echo e($job->title); ?></h3>
                    </div>
                    <div class="card-body">
                        <?php if($applications->count() > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Applicant Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Applied Date</th>
                                            <th>Attachment</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($application->name); ?></td>
                                                <td><?php echo e($application->email); ?></td>
                                                <td><?php echo e($application->phone ?? 'N/A'); ?></td>
                                                <td><?php echo e($application->created_at->format('d M, Y')); ?></td>
                                                <td>
                                                    <?php if($application->resume): ?>
                                                            <a href="<?php echo e(Storage::url($application->resume)); ?>" 
                                                               class="btn btn-sm btn-primary" 
                                                               target="_blank">
                                                                <i class="fa fa-download"></i> Resume
                                                            </a>
                                                        <?php endif; ?>
                                                        <?php if($application->cover_letter): ?>
                                                            <button type="button" 
                                                                    class="btn btn-sm btn-info" 
                                                                    data-bs-toggle="modal" 
                                                                    data-bs-target="#coverLetter<?php echo e($application->id); ?>">
                                                                <i class="fa fa-file-text"></i> Cover Letter
                                                            </button>
                                                        <?php endif; ?>
                                                </td>
                                                <td>
                                                    <span class="badge bg-<?php echo e($application->status == 'approved' ? 'success' : ($application->status == 'rejected' ? 'danger' : 'warning')); ?>">
                                                        <?php echo e(ucfirst($application->status ?? 'pending')); ?>

                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="btn-group">
                                                        <?php if($application->status == 'pending' || $application->status == 'applied'): ?>
                                                            <form action="/job-applications/<?php echo e($application->id); ?>/update-status" method="POST" class="d-inline">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>
                                                                <button type="submit" name="status" value="approved" class="btn btn-sm btn-success">
                                                                    <i class="fa fa-check"></i> Approve
                                                                </button>
                                                                <button type="submit" name="status" value="rejected" class="btn btn-sm btn-danger">
                                                                    <i class="fa fa-times"></i> Reject
                                                                </button>
                                                            </form>
                                                        <?php endif; ?>
                                                        
                                                    </div>
                                                </td>
                                            </tr>

                                            <?php if($application->cover_letter): ?>
                                                <!-- Cover Letter Modal -->
                                                <div class="modal fade" id="coverLetter<?php echo e($application->id); ?>" tabindex="-1">
                                                    <div class="modal-dialog modal-lg">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title">Cover Letter - <?php echo e($application->name); ?></h5>
                                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                            </div>
                                                            <div class="modal-body">
                                                                <?php echo nl2br(e($application->cover_letter)); ?>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="d-flex justify-content-center">
                                <?php echo e($applications->links()); ?>

                            </div>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <h4>No applications received yet.</h4>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\jbportal\resources\views/front/applications/job-applications.blade.php ENDPATH**/ ?>