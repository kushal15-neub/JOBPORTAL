

<?php $__env->startSection('main'); ?>
<section class="section-5 bg-2">
    <div class="container py-5">
        <div class="row">
            <div class="col">
                <div class="card border-0 shadow">
                    <div class="card-header bg-white">
                        <h3 class="mb-0">My Job Applications</h3>
                    </div>
                    <div class="card-body">
                        <?php if($applications->count() > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>Job Title</th>
                                            <th>Applied Date</th>
                                            <th>Company</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <a href="/jobs/<?php echo e($application->job->id); ?>">
                                                        <?php echo e($application->job->title); ?>

                                                    </a>
                                                </td>
                                                <td><?php echo e($application->created_at->format('d M, Y')); ?></td>
                                                <td><?php echo e($application->job->company_name ?? 'N/A'); ?></td>
                                                <td>
                                                    <div class="badge bg-<?php echo e($application->status == 'approved' ? 'success' : ($application->status == 'pending' || $application->status == 'applied' ? 'warning' : 'danger')); ?>">
                                                        <?php echo e(ucfirst($application->status ?? 'pending')); ?>

                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <div class="d-flex justify-content-center">
                                <?php echo e($applications->links()); ?>

                            </div>
                        <?php else: ?>
                            <div class="text-center py-5">
                                <h4>You haven't applied for any jobs yet.</h4>
                                <a href="/" class="btn btn-primary mt-3">Browse Jobs</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\jbportal\resources\views/front/applications/index.blade.php ENDPATH**/ ?>