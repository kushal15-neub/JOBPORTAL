

<?php $__env->startSection('main'); ?>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<section class="section-4 bg-2">    
    <div class="container pt-5">
        <div class="row">
            <div class="col">
                <nav aria-label="breadcrumb" class="rounded-3 p-3">
                    <ol class="breadcrumb mb-0">
                        <li class="breadcrumb-item"><a href="/"><i class="fa fa-arrow-left" aria-hidden="true"></i> &nbsp;Back to Jobs</a></li>
                    </ol>
                </nav>
            </div>
        </div> 
    </div>
    <div class="container job_details_area">
        <div class="row pb-5">
            <div class="col-md-8">
                <div class="card shadow border-0">
                    <div class="job_details_header">
                        <div class="single_jobs white-bg d-flex justify-content-between">
                            <div class="jobs_left d-flex align-items-center">
                                <div class="jobs_conetent">
                                    <a href="#">
                                        <h4><?php echo e($job->title); ?></h4>
                                    </a>
                                    <div class="links_locat d-flex align-items-center">
                                        <div class="location">
                                            <p> <i class="fa fa-map-marker"></i> <?php echo e($job->location); ?></p>
                                        </div>
                                        <div class="location">
                                            <p> <i class="fa fa-clock-o"></i> <?php echo e($job->job_type); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="jobs_right">
                                <div class="apply_now">
                                    <a class="heart_mark" href="#"> <i class="fa fa-heart-o" aria-hidden="true"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="descript_wrap white-bg">
                        <div class="single_wrap">
                            <h4>Job description</h4>
                            <p><?php echo e($job->description); ?></p>
                        </div>
                        <?php if($job->responsibility): ?>
                        <div class="single_wrap">
                            <h4>Responsibility</h4>
                            <?php echo $job->responsibility; ?>

                        </div>
                        <?php endif; ?>
                        <?php if($job->qualifications): ?>
                        <div class="single_wrap">
                            <h4>Qualifications</h4>
                            <?php echo $job->qualifications; ?>

                        </div>
                        <?php endif; ?>
                        <?php if($job->benefits): ?>
                        <div class="single_wrap">
                            <h4>Benefits</h4>
                            <?php echo $job->benefits; ?>

                        </div>
                        <?php endif; ?>
                        <div class="border-bottom"></div>
                        <div class="pt-3 text-end">
                            <?php if($job->applied): ?>
                            <button  class="btn btn-primary" disabled>Already Applied</button>
                            <?php else: ?>
                            <a href="/jobs/<?php echo e($job->id); ?>/apply" class="btn btn-primary">Apply</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card shadow border-0">
                    <div class="job_sumary">
                        <div class="summery_header pb-1 pt-4">
                            <h3>Job Summary</h3>
                        </div>
                        <div class="job_content pt-3">
                            <ul>
                                <li>Published on: <span><?php echo e($job->created_at->format('d M, Y')); ?></span></li>
                                <?php if($job->vacancy): ?>
                                <li>Vacancy: <span><?php echo e($job->vacancy); ?> Position</span></li>
                                <?php endif; ?>
                                <li>Salary: <span><?php echo e($job->salary); ?></span></li>
                                <li>Location: <span><?php echo e($job->location); ?></span></li>
                                <li>Job Nature: <span><?php echo e($job->job_type); ?></span></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php if($job->company): ?>
                <div class="card shadow border-0 my-4">
                    <div class="job_sumary">
                        <div class="summery_header pb-1 pt-4">
                            <h3>Company Details</h3>
                        </div>
                        <div class="job_content pt-3">
                            <ul>
                                <li>Name: <span><?php echo e($job->company->name); ?></span></li>
                                <li>Location: <span><?php echo e($job->company->location); ?></span></li>
                                <?php if($job->company->website): ?>
                                <li>Website: <span><?php echo e($job->company->website); ?></span></li>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('front.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\jbportal\resources\views/front/jobs/show.blade.php ENDPATH**/ ?>